
 <div class="row">
     <div class="col-md-12 col-sm-12">
         <div class="card  card-box">
             <div class="card-head">
                 <header>Peminjaman Ruang</header>
                 <div class="tools">
                     <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                     <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                     <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                 </div>
             </div>
             <div class="card-body ">
               <div class="table-wrap">
                     <div class="table-responsive">
                         <table class="table display product-overview mb-30" id="support_table5">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>No Surat</th>
                                    <th>Tanggal Peminjaman</th>
                                    <th >Ruang</th>
                                    <th>Jumlah Peserta</th>
                                    <th>Penyelenggara</th>
                                    <th>Status</th>
                                    <th>Keterangan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1?>
                                <?php foreach ($ruang as $row): ?>
                                    <tr>
                                        <td><?= $no ?></td>
                                        <td><?= getColumn('peminjam',['id'=>$row->peminjam_id])->no_surat ?></td>
                                        <td><?= $row->tanggal_peminjaman ?></td>
                                        <td><?= getColumn('ruang',['id'=>$row->ruang_id])->nama_ruang ?></td>
                                        <td><?= $row->jumlah_peserta ?></td>
                                        <td><?= getColumn('peminjam',['id'=>$row->peminjam_id])->nama_peminjam ?></td>
                                        <td><?= $row->status ?></td>
                                        <td><?= $row->keterangan ?></td>
                                    </tr>
                                    <?php $no++?>
                                <?php endforeach?>
                            </tbody>
                         </table>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
 <!-- end Payment Details -->
 <div class="row">
     <div class="col-md-12 col-sm-12">
         <div class="card  card-box">
             <div class="card-head">
                 <header>Peminjaman Mobil</header>
                 <div class="tools">
                     <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                     <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                     <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                 </div>
             </div>
             <div class="card-body ">
               <div class="table-wrap">
                     <div class="table-responsive">
                         <table class="table display product-overview mb-30" id="support_table5">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>No Surat</th>
                                    <th>Tanggal Peminjaman</th>
                                    <th >Mobil</th>
                                    <th >Tujuan</th>
                                    <th>Jumlah Peserta</th>
                                    <th>Penyelenggara</th>
                                    <th>Status</th>
                                    <th>Keterangan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1?>
                                <?php foreach ($mobil as $row): ?>
                                    <tr>
                                        <td><?= $no ?></td>
                                        <td><?= getColumn('peminjam',['id'=>$row->peminjam_id])->no_surat ?></td>
                                        <td><?= $row->tanggal_peminjaman ?></td>
                                        <td><?= getColumn('mobil',['id'=>$row->mobil_id])->merk ?></td>
                                        <td><?= $row->tempat ?></td>
                                        <td><?= $row->jumlah_peserta ?></td>
                                        <td><?= getColumn('peminjam',['id'=>$row->peminjam_id])->nama_peminjam ?></td>
                                        <td><?= $row->status ?></td>
                                        <td><?= $row->keterangan ?></td>
                                    </tr>
                                    <?php $no++?>
                                <?php endforeach?>
                            </tbody>
                         </table>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>