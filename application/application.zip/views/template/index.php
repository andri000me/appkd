<?php 
    $CI =& get_instance();
    $setting = $CI->db->get('setting')->row();
    
 ?>

<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta name="description" content="Responsive Admin Template" />
    <meta name="author" content="SmartUniversity" />
    <title><?= $setting->app_name ?></title>
    <!-- google font -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet" type="text/css" />
    <!-- icons -->
    <link href="<?= base_url() ?>assets/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
    <!--bootstrap -->
    <link href="<?= base_url() ?>assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>assets/plugins/summernote/summernote.css" rel="stylesheet">
    <!-- morris chart -->
    <link href="<?= base_url() ?>assets/plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- Material Design Lite CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>assets/plugins/material/material.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>assets/css/material_style.css">
    <!-- animation -->
    <link href="<?= base_url() ?>assets/css/pages/animate_page.css" rel="stylesheet">
    <!-- Template Styles -->
    <link href="<?= base_url() ?>assets/css/plugins.min.css" rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>assets/css/style.css" rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>assets/css/responsive.css" rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>assets/css/theme-color.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="<?= base_url() ?>assets/plugins/jquery-toast/dist/jquery.toast.min.css">

    <!-- favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" />
 </head>
 <!-- END HEAD -->
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white dark-sidebar-color logo-green " onload="loadTable()" >
    <div class="page-wrapper">
      <?php 
        $this->load->view('template/header');
       ?>
        <!-- start page container -->
        <div class="page-container">
            <?php 
                if ($this->uri->segment(1)!='') {
                    
                $this->load->view('template/sidebar');
                }
                
                // $this->load->view('template/chat');
             ?>
        <div class="page-content-wrapper">
            <div class="page-content">
                <div class="page-bar">
                    <div class="page-title-breadcrumb">
                        <div class=" pull-left">
                            <div class="page-title">
                                <?= ucfirst($this->uri->segment(1)) ?></div>
                        </div>
                        <ol class="breadcrumb page-breadcrumb pull-right">
                            <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="<?= site_url('home') ?>">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                            </li>
                            <li><a class="parent-item" href="<?= site_url($this->uri->segment(1)) ?>"><?= ucfirst($this->uri->segment(1)) ?></a>&nbsp;<i class="fa fa-angle-right"></i>
                            </li>
                            <li class="active"><?= ucfirst($this->uri->segment(2)) ?></li>
                        </ol>
                    </div>
                </div>
                <?= $content ?>
            </div>
        </div>

           
           
        </div>
        <!-- end page container -->
       <?php 
            $this->load->view('template/footer');
        ?>
    </div>
    <!-- start js include path -->
    <script src="<?= base_url() ?>assets/plugins/jquery/jquery.min.js" ></script>
    <script src="<?= base_url() ?>assets/plugins/popper/popper.min.js" ></script>
    <script src="<?= base_url() ?>assets/plugins/jquery-blockui/jquery.blockui.min.js" ></script>
    <script src="<?= base_url() ?>assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
    <!-- bootstrap -->
    <script src="<?= base_url() ?>assets/plugins/bootstrap/js/bootstrap.min.js" ></script>
    <script src="<?= base_url() ?>assets/plugins/sparkline/jquery.sparkline.min.js" ></script>
    <script src="<?= base_url() ?>assets/js/pages/sparkline/sparkline-data.js" ></script>
    <!-- Common js-->
    <script src="<?= base_url() ?>assets/js/app.js" ></script>
    <script src="<?= base_url() ?>assets/js/layout.js" ></script>
    <script src="<?= base_url() ?>assets/js/theme-color.js" ></script>
    <!-- material -->
    <script src="<?= base_url() ?>assets/plugins/material/material.min.js"></script>
    <!-- animation -->
    <script src="<?= base_url() ?>assets/js/pages/ui/animations.js" ></script>
    <!-- morris chart -->
    <script src="<?= base_url() ?>assets/plugins/morris/morris.min.js" ></script>
    <script src="<?= base_url() ?>assets/plugins/morris/raphael-min.js" ></script>
    <script src="<?= base_url() ?>assets/js/pages/chart/morris/morris_home_data.js" ></script>

    <script src="<?= base_url() ?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?= base_url() ?>assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js" ></script>
    <script src="<?= base_url() ?>assets/plugins/jquery-toast/dist/jquery.toast.min.js" ></script>


    <!-- <script src="<?= base_url() ?>assets/js/pages/table/table_data.js" ></script> -->

    <!-- end js include path -->
    <script type="text/javascript">
        $(function() {
            $('.table').DataTable({
                // "scrollX": true,
                "paging":true
            })
        });
    </script>
  </body>
</html>
