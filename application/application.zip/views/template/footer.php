<?php 
    $CI =& get_instance();
    $setting = $CI->db->get('setting')->row()
 ?>

<!-- start footer -->
<div class="page-footer">
    <div class="page-footer-inner"> <?= date("Y") ?> &copy; <?= strtoupper($setting->app_name) ?>
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
<!-- end footer -->