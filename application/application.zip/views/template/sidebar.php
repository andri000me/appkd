<?php 
    $CI =& get_instance();
    $setting = $CI->db->get('setting')->row()
 ?>
<!-- start sidebar menu -->
<div class="sidebar-container sidebar-green">
    <div class="sidemenu-container sidebar-green navbar-collapse collapse fixed-menu">
        <div id="remove-scroll">
            <ul class="sidemenu page-header-fixed p-t-20" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
                <li class="sidebar-toggler-wrapper hide">
                    <div class="sidebar-toggler">
                        <span></span>
                    </div>
                </li>
                <li class="sidebar-user-panel">
                    <div class="user-panel">
                        <div class="row">
                                <div class="sidebar-userpic">
                                    <img src="<?= base_url() ?>assets/img/<?= $setting->logo?>" class="img-responsive" alt=""> </div>
                            </div>
                            <div class="profile-usertitle">
                                <div class="sidebar-userpic-name"> <?= $this->session->userdata('email'); ?>  </div>
                                <div class="profile-usertitle-job"> <?= $this->session->userdata('hak_akses'); ?> </div>
                            </div>
                            
                    </div>
                </li>
                <li class="menu-heading">
                    <span>MAIN MENU</span>
                </li>
                <li class="nav-item">
                    <a href="<?= site_url('penanggung_jawab') ?>" class="nav-link nav-toggle"> <i class="material-icons">group</i>
                        <span class="title">Penanggung Jawab</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?= site_url('ruang') ?>" class="nav-link nav-toggle"> <i class="material-icons">vpn_key</i>
                        <span class="title">Ruang</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link nav-toggle">
                        <i class="material-icons">widgets</i>
                        <span class="title">Perlengkapan</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub-menu">
                        <li class="nav-item">
                            <a href="<?= site_url('perlengkapan') ?>" class="nav-link ">
                                <span class="title">Perlengkapan</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= site_url('mobil') ?>" class="nav-link ">
                                <span class="title">Mobil</span>
                            </a>
                        </li>
                    </ul>
                </li>
               
                <li class="nav-item">
                    <a href="<?= site_url('sopir') ?>" class="nav-link nav-toggle"> <i class="material-icons">drive_eta</i>
                        <span class="title">Sopir</span>
                    </a>
                </li>
               
                <li class="nav-item">
                    <a href="<?= site_url('peminjam') ?>" class="nav-link nav-toggle"> <i class="material-icons">group</i>
                        <span class="title">Peminjam</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link nav-toggle">
                        <i class="material-icons">widgets</i>
                        <span class="title">Peminjaman</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub-menu">
                        <li class="nav-item">
                            <a href="<?= site_url('peminjaman?jenis=ruang') ?>" class="nav-link ">
                                <span class="title">Ruang</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= site_url('peminjaman?jenis=mobil') ?>" class="nav-link ">
                                <span class="title">Mobil</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= site_url('perlengkapan/daftar_peminjaman') ?>" title="Perlengkapan">Perlengkapan</a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link nav-toggle">
                        <i class="material-icons">book</i>
                        <span class="title">Manual Book</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub-menu">
                        <?php 
                            $map = directory_map('./gambar',1);
                         ?>

                        <?php for ($i = 0; $i < count($map); $i++) { ?>
                             <li class="nav-item">
                               
                                 <a href="<?= site_url('home/book/'.$map[$i]) ?>" class="nav-link ">
                                     <span class="title"><?= $map[$i] ?></span>
                                 </a>
                             </li>
                        <?php } ?>
                                            </ul>
                </li>

            </ul>
        </div>
    </div>
</div>
<!-- end sidebar menu -->