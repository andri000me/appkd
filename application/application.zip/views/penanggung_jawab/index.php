<?php if ($this->session->userdata('success')): ?>
    <div class="alert alert-success">
        <strong>Success!</strong><?= $this->session->userdata('success'); ?>.
    </div>
<?php endif ?>
<div class="row">
    <div class="col-md-12">
        <div class="card card-topline-aqua">
            <div class="card-head">
                <a href="<?= site_url('penanggung_jawab/tambah') ?>" class="btn btn-primary" title="Tambah">Tambah</a>
                <header>DAFTAR Penanggung Jawab</header>
                <div class="tools">
                    <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                    <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                    <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                </div>
            </div>
            <div class="card-body ">
              <div class="table-scrollable">
                <table class="display table table-bordered" class="full-width">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jabatan</th>
                            <th>Alamat</th>
                            <th>No Hp</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no=1 ?>
                        <?php foreach ($penanggung_jawab as $row): ?>
                            <tr>
                                <td><?= $no ?></td>
                                <td><?= $row->nama ?></td>
                                <td><?= $row->jabatan ?></td>
                                <td><?= $row->alamat ?></td>
                                <td><?= $row->no_hp ?></td>
                                <td>
                                    <a href="<?= site_url('penanggung_jawab/edit/'.$row->id) ?>" class="btn btn-warning" title="Edit">Edit</a>
                                    <a onclick=" return confirm('Apakah Anda yakin akan Hapus?') " href="<?= site_url('penanggung_jawab/delete/'.$row->id) ?>" class="btn btn-danger">Hapus</a>
                                </td>
                            </tr>
                            <?php $no++ ?>
                        <?php endforeach ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>


